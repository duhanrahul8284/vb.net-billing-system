﻿Public Class Form1
    Const bread = 20
    Const rice = 40
    Const beans = 50
    Const juice = 20
    Const milk = 25

    Dim item(9)
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim iQuit As DialogResult
        iQuit = MessageBox.Show("Conform if you want to quit", "Billing Management System",
MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If iQuit = DialogResult.Yes Then
            Application.Exit()
        End If
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles lblItembread.Click

    End Sub

    Private Sub NumericUpDown1_ValueChanged(sender As Object, e As EventArgs) Handles Numerbread.ValueChanged
        lblBread.Text = FormatCurrency(Numerbread.Value * bread)
    End Sub

    Private Sub Label13_Click(sender As Object, e As EventArgs) Handles Label13.Click

    End Sub

    Private Sub Label12_Click(sender As Object, e As EventArgs) Handles Label12.Click

    End Sub

    Private Sub Numerrice_ValueChanged(sender As Object, e As EventArgs) Handles Numerrice.ValueChanged
        lblrice.Text = FormatCurrency(Numerrice.Value * rice)
    End Sub

    Private Sub Numerbeans_ValueChanged(sender As Object, e As EventArgs) Handles Numerbeans.ValueChanged
        lblbeans.Text = FormatCurrency(Numerbeans.Value * beans)
    End Sub

    Private Sub Numerjuice_ValueChanged(sender As Object, e As EventArgs) Handles Numerjuice.ValueChanged
        lbljuice.Text = FormatCurrency(Numerjuice.Value * juice)
    End Sub

    Private Sub Numermilk_ValueChanged(sender As Object, e As EventArgs) Handles Numermilk.ValueChanged
        lblmilk.Text = FormatCurrency(Numermilk.Value * milk)
    End Sub

    Private Sub btmreset_Click(sender As Object, e As EventArgs) Handles btmreset.Click
        Numerbread.Value = 0
        Numerrice.Value = 0
        Numerbeans.Value = 0
        Numerjuice.Value = 0
        Numermilk.Value = 0

        lblBread.Text = "₹0.00"
        lblrice.Text = "₹0.00"
        lblbeans.Text = "₹0.00"
        lbljuice.Text = "₹0.00"
        lblmilk.Text = "₹0.00"
        lblTotal.Text = "₹0.00"
        lblnumitems.Text = "0"
        rtReceipt.Clear()


    End Sub

    Private Sub lblnumitem_Click(sender As Object, e As EventArgs) Handles lblTotal.Click

    End Sub

    Private Sub btmtotal_Click(sender As Object, e As EventArgs) Handles btmtotal.Click
        item(0) = Numerbread.Value * bread
        item(1) = Numerrice.Value * rice
        item(2) = Numerbeans.Value * beans
        item(3) = Numerjuice.Value * juice
        item(4) = Numermilk.Value * milk

        item(5) = item(0) + item(1) + item(2) + item(3) + item(4)
        lblTotal.Text = FormatCurrency(item(5))

        Dim q(9)
        q(0) = Numerbread.Value
        q(1) = Numerrice.Value
        q(2) = Numerbeans.Value
        q(3) = Numerjuice.Value
        q(4) = Numermilk.Value

        q(5) = q(0) + q(1) + q(2) + q(3) + q(4)
        lblnumitems.Text = q(5)

    End Sub

    Private Sub Panel6_Paint(sender As Object, e As PaintEventArgs)

    End Sub

    Private Sub btmreceipt_Click(sender As Object, e As EventArgs) Handles btmreceipt.Click

        rtReceipt.AppendText(Label11.Text & vbTab & Label12.Text & vbTab & Label13.Text & vbNewLine)

        rtReceipt.AppendText(lblItembread.Text & vbTab & Numerbread.Value & vbTab & lblBread.Text & vbNewLine)
        rtReceipt.AppendText(lblItemrice.Text & vbTab & vbTab & Numerrice.Value & vbTab & lblrice.Text & vbNewLine)
        rtReceipt.AppendText(lblItembeans.Text & vbTab & Numerbeans.Value & vbTab & lblbeans.Text & vbNewLine)
        rtReceipt.AppendText(lblItemjuice.Text & vbTab & vbTab & Numerjuice.Value & vbTab & lbljuice.Text & vbNewLine)
        rtReceipt.AppendText(lblItemMilk.Text & vbTab & vbTab & Numermilk.Value & vbTab & lblmilk.Text & vbNewLine)

        rtReceipt.AppendText(Label15.Text & vbTab & lblnumitems.Text & vbTab & lblTotal.Text & vbNewLine)
    End Sub

    Private Sub Label8_Click(sender As Object, e As EventArgs) Handles lblItemjuice.Click

    End Sub
End Class
