﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.btmreset = New System.Windows.Forms.Button()
        Me.btmreceipt = New System.Windows.Forms.Button()
        Me.btmtotal = New System.Windows.Forms.Button()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.rtReceipt = New System.Windows.Forms.RichTextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lblnumitems = New System.Windows.Forms.Label()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Numermilk = New System.Windows.Forms.NumericUpDown()
        Me.lblmilk = New System.Windows.Forms.Label()
        Me.lblItemMilk = New System.Windows.Forms.Label()
        Me.Numerjuice = New System.Windows.Forms.NumericUpDown()
        Me.lbljuice = New System.Windows.Forms.Label()
        Me.lblItemjuice = New System.Windows.Forms.Label()
        Me.Numerbeans = New System.Windows.Forms.NumericUpDown()
        Me.lblbeans = New System.Windows.Forms.Label()
        Me.lblItembeans = New System.Windows.Forms.Label()
        Me.Numerrice = New System.Windows.Forms.NumericUpDown()
        Me.lblrice = New System.Windows.Forms.Label()
        Me.lblItemrice = New System.Windows.Forms.Label()
        Me.Numerbread = New System.Windows.Forms.NumericUpDown()
        Me.lblBread = New System.Windows.Forms.Label()
        Me.lblItembread = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.Numermilk, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Numerjuice, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Numerbeans, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Numerrice, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Numerbread, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.Highlight
        Me.Panel1.Controls.Add(Me.Panel5)
        Me.Panel1.Controls.Add(Me.Panel4)
        Me.Panel1.Controls.Add(Me.Panel3)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Location = New System.Drawing.Point(12, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1340, 720)
        Me.Panel1.TabIndex = 0
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.SystemColors.Control
        Me.Panel5.Controls.Add(Me.Button4)
        Me.Panel5.Controls.Add(Me.btmreset)
        Me.Panel5.Controls.Add(Me.btmreceipt)
        Me.Panel5.Controls.Add(Me.btmtotal)
        Me.Panel5.Location = New System.Drawing.Point(34, 628)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(1277, 75)
        Me.Panel5.TabIndex = 3
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.Button4.Font = New System.Drawing.Font("Segoe UI", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Button4.Location = New System.Drawing.Point(1003, 15)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(224, 44)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "EXIT"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'btmreset
        '
        Me.btmreset.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.btmreset.Font = New System.Drawing.Font("Segoe UI", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btmreset.Location = New System.Drawing.Point(696, 15)
        Me.btmreset.Name = "btmreset"
        Me.btmreset.Size = New System.Drawing.Size(224, 44)
        Me.btmreset.TabIndex = 2
        Me.btmreset.Text = "Reset"
        Me.btmreset.UseVisualStyleBackColor = False
        '
        'btmreceipt
        '
        Me.btmreceipt.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.btmreceipt.Font = New System.Drawing.Font("Segoe UI", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btmreceipt.Location = New System.Drawing.Point(360, 14)
        Me.btmreceipt.Name = "btmreceipt"
        Me.btmreceipt.Size = New System.Drawing.Size(224, 44)
        Me.btmreceipt.TabIndex = 1
        Me.btmreceipt.Text = "Receipt"
        Me.btmreceipt.UseVisualStyleBackColor = False
        '
        'btmtotal
        '
        Me.btmtotal.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.btmtotal.Font = New System.Drawing.Font("Segoe UI", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btmtotal.Location = New System.Drawing.Point(51, 14)
        Me.btmtotal.Name = "btmtotal"
        Me.btmtotal.Size = New System.Drawing.Size(224, 44)
        Me.btmtotal.TabIndex = 0
        Me.btmtotal.Text = "Total"
        Me.btmtotal.UseVisualStyleBackColor = False
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.SystemColors.Control
        Me.Panel4.Controls.Add(Me.Label1)
        Me.Panel4.Location = New System.Drawing.Point(34, 22)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(1277, 75)
        Me.Panel4.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label1.ForeColor = System.Drawing.SystemColors.Highlight
        Me.Label1.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Label1.Location = New System.Drawing.Point(144, -22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(989, 96)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Billing Management System"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.SystemColors.Control
        Me.Panel3.Controls.Add(Me.rtReceipt)
        Me.Panel3.Controls.Add(Me.Label9)
        Me.Panel3.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point)
        Me.Panel3.Location = New System.Drawing.Point(896, 103)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(415, 519)
        Me.Panel3.TabIndex = 1
        '
        'rtReceipt
        '
        Me.rtReceipt.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point)
        Me.rtReceipt.Location = New System.Drawing.Point(19, 94)
        Me.rtReceipt.Name = "rtReceipt"
        Me.rtReceipt.Size = New System.Drawing.Size(377, 399)
        Me.rtReceipt.TabIndex = 26
        Me.rtReceipt.Text = ""
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point)
        Me.Label9.Location = New System.Drawing.Point(102, 22)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(210, 40)
        Me.Label9.TabIndex = 25
        Me.Label9.Text = "Cost of Item"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Linen
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.lblnumitems)
        Me.Panel2.Controls.Add(Me.lblTotal)
        Me.Panel2.Controls.Add(Me.Label15)
        Me.Panel2.Controls.Add(Me.Label13)
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Controls.Add(Me.Numermilk)
        Me.Panel2.Controls.Add(Me.lblmilk)
        Me.Panel2.Controls.Add(Me.lblItemMilk)
        Me.Panel2.Controls.Add(Me.Numerjuice)
        Me.Panel2.Controls.Add(Me.lbljuice)
        Me.Panel2.Controls.Add(Me.lblItemjuice)
        Me.Panel2.Controls.Add(Me.Numerbeans)
        Me.Panel2.Controls.Add(Me.lblbeans)
        Me.Panel2.Controls.Add(Me.lblItembeans)
        Me.Panel2.Controls.Add(Me.Numerrice)
        Me.Panel2.Controls.Add(Me.lblrice)
        Me.Panel2.Controls.Add(Me.lblItemrice)
        Me.Panel2.Controls.Add(Me.Numerbread)
        Me.Panel2.Controls.Add(Me.lblBread)
        Me.Panel2.Controls.Add(Me.lblItembread)
        Me.Panel2.Location = New System.Drawing.Point(34, 103)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(841, 519)
        Me.Panel2.TabIndex = 0
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point)
        Me.Label3.Location = New System.Drawing.Point(355, -54)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(91, 40)
        Me.Label3.TabIndex = 24
        Me.Label3.Text = "Cost"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point)
        Me.Label5.Location = New System.Drawing.Point(-31, -54)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(192, 40)
        Me.Label5.TabIndex = 23
        Me.Label5.Text = "No. of Item"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point)
        Me.Label7.Location = New System.Drawing.Point(-221, -54)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(86, 40)
        Me.Label7.TabIndex = 22
        Me.Label7.Text = "Item"
        '
        'lblnumitems
        '
        Me.lblnumitems.BackColor = System.Drawing.Color.White
        Me.lblnumitems.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblnumitems.Location = New System.Drawing.Point(212, 429)
        Me.lblnumitems.Name = "lblnumitems"
        Me.lblnumitems.Size = New System.Drawing.Size(261, 40)
        Me.lblnumitems.TabIndex = 20
        Me.lblnumitems.Text = "0"
        Me.lblnumitems.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTotal
        '
        Me.lblTotal.BackColor = System.Drawing.Color.White
        Me.lblTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblTotal.Location = New System.Drawing.Point(545, 427)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(261, 40)
        Me.lblTotal.TabIndex = 19
        Me.lblTotal.Text = "₹0.00"
        Me.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label15.Location = New System.Drawing.Point(32, 427)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(164, 37)
        Me.Label15.TabIndex = 18
        Me.Label15.Text = "Total Cost"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point)
        Me.Label13.Location = New System.Drawing.Point(608, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(91, 40)
        Me.Label13.TabIndex = 17
        Me.Label13.Text = "Cost"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point)
        Me.Label12.Location = New System.Drawing.Point(222, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(192, 40)
        Me.Label12.TabIndex = 16
        Me.Label12.Text = "No. of Item"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point)
        Me.Label11.Location = New System.Drawing.Point(32, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(86, 40)
        Me.Label11.TabIndex = 15
        Me.Label11.Text = "Item"
        '
        'Numermilk
        '
        Me.Numermilk.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Numermilk.Location = New System.Drawing.Point(212, 353)
        Me.Numermilk.Name = "Numermilk"
        Me.Numermilk.Size = New System.Drawing.Size(263, 44)
        Me.Numermilk.TabIndex = 14
        Me.Numermilk.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblmilk
        '
        Me.lblmilk.BackColor = System.Drawing.Color.White
        Me.lblmilk.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblmilk.Location = New System.Drawing.Point(543, 353)
        Me.lblmilk.Name = "lblmilk"
        Me.lblmilk.Size = New System.Drawing.Size(261, 40)
        Me.lblmilk.TabIndex = 13
        Me.lblmilk.Text = "₹0.00"
        Me.lblmilk.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblItemMilk
        '
        Me.lblItemMilk.AutoSize = True
        Me.lblItemMilk.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblItemMilk.Location = New System.Drawing.Point(32, 355)
        Me.lblItemMilk.Name = "lblItemMilk"
        Me.lblItemMilk.Size = New System.Drawing.Size(73, 37)
        Me.lblItemMilk.TabIndex = 12
        Me.lblItemMilk.Text = "Milk"
        '
        'Numerjuice
        '
        Me.Numerjuice.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Numerjuice.Location = New System.Drawing.Point(212, 272)
        Me.Numerjuice.Name = "Numerjuice"
        Me.Numerjuice.Size = New System.Drawing.Size(263, 44)
        Me.Numerjuice.TabIndex = 11
        Me.Numerjuice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbljuice
        '
        Me.lbljuice.BackColor = System.Drawing.Color.White
        Me.lbljuice.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lbljuice.Location = New System.Drawing.Point(543, 272)
        Me.lbljuice.Name = "lbljuice"
        Me.lbljuice.Size = New System.Drawing.Size(261, 40)
        Me.lbljuice.TabIndex = 10
        Me.lbljuice.Text = "₹0.00"
        Me.lbljuice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblItemjuice
        '
        Me.lblItemjuice.AutoSize = True
        Me.lblItemjuice.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblItemjuice.Location = New System.Drawing.Point(32, 274)
        Me.lblItemjuice.Name = "lblItemjuice"
        Me.lblItemjuice.Size = New System.Drawing.Size(91, 37)
        Me.lblItemjuice.TabIndex = 9
        Me.lblItemjuice.Text = "Juice"
        '
        'Numerbeans
        '
        Me.Numerbeans.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Numerbeans.Location = New System.Drawing.Point(212, 195)
        Me.Numerbeans.Name = "Numerbeans"
        Me.Numerbeans.Size = New System.Drawing.Size(263, 44)
        Me.Numerbeans.TabIndex = 8
        Me.Numerbeans.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblbeans
        '
        Me.lblbeans.BackColor = System.Drawing.Color.White
        Me.lblbeans.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblbeans.Location = New System.Drawing.Point(543, 195)
        Me.lblbeans.Name = "lblbeans"
        Me.lblbeans.Size = New System.Drawing.Size(261, 40)
        Me.lblbeans.TabIndex = 7
        Me.lblbeans.Text = "₹0.00"
        Me.lblbeans.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblItembeans
        '
        Me.lblItembeans.AutoSize = True
        Me.lblItembeans.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblItembeans.Location = New System.Drawing.Point(32, 197)
        Me.lblItembeans.Name = "lblItembeans"
        Me.lblItembeans.Size = New System.Drawing.Size(107, 37)
        Me.lblItembeans.TabIndex = 6
        Me.lblItembeans.Text = "Beans"
        '
        'Numerrice
        '
        Me.Numerrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Numerrice.Location = New System.Drawing.Point(212, 127)
        Me.Numerrice.Name = "Numerrice"
        Me.Numerrice.Size = New System.Drawing.Size(263, 44)
        Me.Numerrice.TabIndex = 5
        Me.Numerrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblrice
        '
        Me.lblrice.BackColor = System.Drawing.Color.White
        Me.lblrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblrice.Location = New System.Drawing.Point(543, 127)
        Me.lblrice.Name = "lblrice"
        Me.lblrice.Size = New System.Drawing.Size(261, 40)
        Me.lblrice.TabIndex = 4
        Me.lblrice.Text = "₹0.00"
        Me.lblrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblItemrice
        '
        Me.lblItemrice.AutoSize = True
        Me.lblItemrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblItemrice.Location = New System.Drawing.Point(32, 129)
        Me.lblItemrice.Name = "lblItemrice"
        Me.lblItemrice.Size = New System.Drawing.Size(79, 37)
        Me.lblItemrice.TabIndex = 3
        Me.lblItemrice.Text = "Rice"
        '
        'Numerbread
        '
        Me.Numerbread.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Numerbread.Location = New System.Drawing.Point(212, 57)
        Me.Numerbread.Name = "Numerbread"
        Me.Numerbread.Size = New System.Drawing.Size(263, 44)
        Me.Numerbread.TabIndex = 2
        Me.Numerbread.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblBread
        '
        Me.lblBread.BackColor = System.Drawing.Color.White
        Me.lblBread.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblBread.Location = New System.Drawing.Point(543, 57)
        Me.lblBread.Name = "lblBread"
        Me.lblBread.Size = New System.Drawing.Size(261, 40)
        Me.lblBread.TabIndex = 1
        Me.lblBread.Text = "₹0.00"
        Me.lblBread.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblItembread
        '
        Me.lblItembread.AutoSize = True
        Me.lblItembread.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblItembread.Location = New System.Drawing.Point(32, 59)
        Me.lblItembread.Name = "lblItembread"
        Me.lblItembread.Size = New System.Drawing.Size(102, 37)
        Me.lblItembread.TabIndex = 0
        Me.lblItembread.Text = "Bread"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1364, 744)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.Panel1.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.Numermilk, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Numerjuice, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Numerbeans, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Numerrice, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Numerbread, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Button4 As Button
    Friend WithEvents btmreset As Button
    Friend WithEvents btmreceipt As Button
    Friend WithEvents btmtotal As Button
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Numerbread As NumericUpDown
    Friend WithEvents lblBread As Label
    Friend WithEvents lblItembread As Label
    Friend WithEvents Numermilk As NumericUpDown
    Friend WithEvents lblmilk As Label
    Friend WithEvents lblItemMilk As Label
    Friend WithEvents Numerjuice As NumericUpDown
    Friend WithEvents lbljuice As Label
    Friend WithEvents lblItemjuice As Label
    Friend WithEvents Numerbeans As NumericUpDown
    Friend WithEvents lblbeans As Label
    Friend WithEvents lblItembeans As Label
    Friend WithEvents Numerrice As NumericUpDown
    Friend WithEvents lblrice As Label
    Friend WithEvents lblItemrice As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents lblnumitems As Label
    Friend WithEvents lblTotal As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents rtReceipt As RichTextBox
    Friend WithEvents Label9 As Label
End Class
